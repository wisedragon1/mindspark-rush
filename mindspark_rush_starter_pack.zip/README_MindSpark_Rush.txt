MINDSpark RUSH — PROTOTYPE + LAUNCH PLAN
========================================

WHAT'S INCLUDED
- mindspark_rush.html: a complete single-file, mobile-friendly browser game.
- No build tools or paid services are required to test it.
- Includes a 60-second round, multiple-choice questions, scoring, streak multipliers,
  a personal best saved on the device, and share/challenge functionality.
- This is a prototype: it does not yet have online accounts, a global leaderboard,
  analytics, a backend, or live advertising.

HOW TO TEST
1. Download mindspark_rush.html to your computer or phone.
2. Open it in a modern browser. If file-opening is restricted on your phone, test it
   on a computer or upload it to a static host first.
3. Play a few rounds on both desktop and mobile.
4. Test the share button. The share action works best on a deployed HTTPS website.

FREE STATIC DEPLOYMENT (GITHUB PAGES)
1. Create or sign in to a GitHub account.
2. Create a new PUBLIC repository, for example "mindspark-rush".
3. Upload mindspark_rush.html and rename it to index.html.
4. Open the repository's Settings, then Pages.
5. Choose deployment from the main branch and the root folder; save.
6. Wait for publishing, then open the site URL GitHub provides.
The public repository/site means your game source is visible. Do not put secret keys
or private information in the game files.

PRACTICAL GROWTH PLAN
Phase 1 — Validate the game (weeks 1–2)
- Share the link with 20–50 real testers and ask where they got confused or bored.
- Watch for broken controls, mobile layout problems, and whether players replay.
- Improve question variety, difficulty, load speed, and the end-of-round challenge.
- Make a 10–15 second vertical gameplay clip with a clear call to action.

Phase 2 — Content-led launch (weeks 3–6)
- Post 1–2 YouTube Shorts per day for 2 weeks: tricky question, countdown, funny
  wrong answer, high-score attempt, and friend-vs-friend challenge.
- Use a consistent CTA: "Play the 60-second challenge — link in description."
- Repost native edits on TikTok, Instagram Reels, Snapchat Spotlight, and Facebook.
- Invite small creators who cover quizzes, puzzles, education, or casual games to try it.
- Ask players to share their actual score; never buy bot views or fake users.

Phase 3 — Improve conversion and retention (weeks 7–12)
- Track video views -> link clicks -> game starts -> completed rounds -> repeat plays.
- Test different hooks, thumbnails, opening questions, and calls to action.
- Add a daily challenge, category selection, accessible controls, and a real leaderboard
  only after testers show repeated interest.
- Consider localization and regional question packs after the core game retains players.

MILESTONES (TARGETS TO TEST, NOT PROMISES)
- First 100 players: learn whether the game is fun and easy to understand.
- 1,000 players: identify which video/channel sends engaged players.
- 10,000 players: improve replay rate and sharing based on actual behavior.
- 100,000 players: add robust backend, abuse prevention, monitoring, and support.
- 1,000,000 players: scale distribution and infrastructure only after growth/retention data
  show that people keep playing. One million users cannot be guaranteed.

BACKEND WORK NEEDED FOR A REAL PUBLIC PRODUCT
- Database and API for accounts, verified scores, daily challenges, and leaderboards.
- Rate limiting, input validation, anti-cheat controls, backups, and error monitoring.
- Privacy notice, data minimization, cookie/analytics consent where required, and a
  contact/support channel if collecting personal data.
- Analytics that measure acquisition, activation, retention, and referral sharing.
- If adding sign-in, never store passwords yourself without a proper authentication system.
- Global leaderboards cannot be trusted if all scores are kept only in the browser.

ADVERTISING
- No ads are included in this prototype.
- First build original content and a useful, reliable game experience, then apply to an
  appropriate ad program and wait for approval. Approval and earnings are not guaranteed.
- Keep ads away from controls and avoid deceptive clicks, forced redirects, or fake traffic.
- For HTML5 game-specific ad options, review Google's H5 Games Ads information and
  eligibility before integrating any SDK:
  https://adsense.google.com/start/h5-game-ads-apply/
- AdSense site eligibility guidance:
  https://support.google.com/adsense/answer/9724

FREE HOSTING REFERENCES
- GitHub Pages overview: https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
- Creating a GitHub Pages site: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

NOTE
This package is a working front-end prototype, not a deployed public website. You still
need to upload it to a host and test the published URL before sharing it widely.
